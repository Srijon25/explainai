# ExplainAI

**ExplainAI** is a lightweight, interactive Python tool to help explain machine learning model predictions using SHAP and LIME. Built for natural language processing (NLP) classification tasks, it enables users to visualize how models make decisions — without needing deep technical knowledge.

## Features

- Upload CSV datasets
- Select the label column
- Generate SHAP and LIME explanations
- Clean, interactive Gradio web interface

## Installation

```bash
git clone https://github.com/Srijon25/explainai.git
cd explainai
pip install -r requirements.txt
```

## Usage

```bash
python app.py
```

This will launch a Gradio interface in your browser. Upload your dataset, select the label column, and view your model's explanation.

## Example Input

| text                  | label |
|-----------------------|-------|
| I love this product   | 1     |
| This is terrible      | 0     |
| Absolutely fantastic  | 1     |

## Dependencies

- `shap`
- `lime`
- `gradio`
- `scikit-learn`
- `pandas`

Install all with:

```bash
pip install -r requirements.txt
```

## License

MIT License

## Citation

If you use this tool in your research, please cite the JOSS paper (coming soon).
