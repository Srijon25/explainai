import unittest
from core import run_lime, run_shap
import pandas as pd

class TestExplainAI(unittest.TestCase):

    def setUp(self):
        self.df = pd.DataFrame({
            'text': ['Great product', 'Awful service', 'Loved it', 'Hated it'],
            'label': [1, 0, 1, 0]
        })

    def test_run_lime_valid(self):
        explanation = run_lime(self.df, 'label')
        self.assertIsNotNone(explanation)

    def test_run_shap_valid(self):
        explanation = run_shap(self.df, 'label')
        self.assertIsNotNone(explanation)

    def test_invalid_label_column(self):
        with self.assertRaises(KeyError):
            run_lime(self.df, 'invalid_label')

    def test_empty_dataframe(self):
        empty_df = pd.DataFrame(columns=['text', 'label'])
        with self.assertRaises(ValueError):
            run_shap(empty_df, 'label')

if __name__ == '__main__':
    unittest.main()
