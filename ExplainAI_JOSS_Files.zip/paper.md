---
title: 'ExplainAI: A Lightweight and Interactive Tool for Model Explainability using SHAP and LIME'
tags:
  - Python
  - NLP
  - Explainability
  - LIME
  - SHAP
  - Machine Learning
authors:
  - name: Srijon Kumar Shill
    orcid: 0009-0004-8924-2272
    affiliation: 1
affiliations:
  - name: Independent Researcher
    index: 1
date: 2025-05-14
---

# Summary

**ExplainAI** is an open-source Python tool designed to improve interpretability in machine learning models, particularly for natural language processing (NLP) classification tasks. It integrates two leading techniques, SHAP (SHapley Additive Explanations) and LIME (Local Interpretable Model-Agnostic Explanations), into a simple and interactive Gradio interface. ExplainAI helps researchers, students, and educators quickly understand the inner workings of their models without writing custom code for interpretability.

# Statement of Need

As machine learning becomes increasingly embedded in research and industry, understanding how models make decisions is critical for trust and transparency. While SHAP and LIME are powerful tools, they often require significant setup and expertise. **ExplainAI** addresses this gap by providing an out-of-the-box solution that enables users to load datasets, select target labels, and visualize model explanations interactively. This tool is especially useful for:

- Researchers validating model fairness or performance.
- Educators demonstrating model behavior to students.
- Practitioners debugging NLP models.

# Functionality

- Upload CSV datasets with textual inputs.
- Select the label column for classification.
- Automatically build and train a basic model.
- Generate interactive SHAP and LIME explanations.
- Visual interface via Gradio — no coding needed.

# Acknowledgements

ExplainAI is built upon widely used open-source libraries including SHAP, LIME, scikit-learn, pandas, and Gradio. Special thanks to the contributors of those tools.

# References

- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). "Why should I trust you?": Explaining the predictions of any classifier. *KDD '16*.
- Lundberg, S. M., & Lee, S.-I. (2017). A Unified Approach to Interpreting Model Predictions. *NIPS*.
