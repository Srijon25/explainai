# Contributing to explainai

Thank you for considering contributing to explainai!

## How to Contribute

1. Fork the repository
2. Create a new branch: `git checkout -b feature-name`
3. Make your changes
4. Run the tests: `pytest`
5. Commit your changes: `git commit -am 'Add new feature'`
6. Push to the branch: `git push origin feature-name`
7. Create a pull request

## Code Style

- Follow PEP8 standards
- Add docstrings to all public functions and classes
- Write tests for new features

## Development Setup

```bash
git clone https://github.com/Srijon25/explainai.git
cd explainai
pip install -e .
```
